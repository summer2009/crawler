"""

@author: liushuchun
"""
import re
import string
import jieba

# 加载停用词
with open("dict/stop_words.utf8", encoding="utf8") as f:
    stopword_list = f.readlines()


def tokenize_text(text):
    tokens = jieba.lcut(text)
    tokens = [token.strip() for token in tokens]
    return tokens


def remove_special_characters(text):
    tokens = tokenize_text(text)
    pattern = re.compile('[{}]'.format(re.escape(string.punctuation)))
    filtered_tokens = filter(None, [pattern.sub('', token) for token in tokens])
    filtered_text = ' '.join(filtered_tokens)
    return filtered_text


def remove_stopwords(text):
    tokens = tokenize_text(text)
    filtered_tokens = [token for token in tokens if token not in stopword_list]
    filtered_text = ''.join(filtered_tokens)
    return filtered_text


def normalize_corpus(corpus):
    normalized_corpus = []
    pat = re.compile('(?<=\>).*?(?=\<)')
    stopSet = stop_words('data/stopWordsChinese.dat')
    for text in corpus:
        
        tmp =" ".join(jieba.lcut(text))
        text = ''.join(pat.findall(tmp))
        #textTmp = del_stop_words(text,stopSet)
        normalized_corpus.append(text)
    
    #去除停用词  

    #return del_stop_words(normalized_corpus,stop_words('data/stopWordsChinese.dat'))
    return normalized_corpus

def read_from_file(file_name):
    with open(file_name,"r") as fp:
        words = fp.read()
    return words

def stop_words(stop_word_file):
    words = read_from_file(stop_word_file)
    result = jieba.cut(words)
    new_words = []
    for r in result:
        new_words.append(r)
    return set(new_words)

def del_stop_words(words,stop_words_set):
#   words是已经切词但是没有去除停用词的文档。
#   返回的会是去除停用词后的文档
    #result = jieba.cut(words)
    new_words = []
    for r in words:
        if r not in stop_words_set:
            new_words.append(r)
    return new_words
